const express = require('express');
const path = require('path');

const app = express();

app.set('view engine', 'pug');
app.set('views', path.join(__dirname, 'views'));

app.use(express.static(path.join(__dirname, 'public')));

app.get('/', (req, res) => res.render('index', { title: 'Головна' }));
app.use('/users', require('./routes/users'));
app.use('/articles', require('./routes/articles'));

app.use((req, res) => {
  res.status(404).render('404', { title: 'Не знайдено', message: 'Сторінку не знайдено' });
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`Server: http://localhost:${PORT}`));
