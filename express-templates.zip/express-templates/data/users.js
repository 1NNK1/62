module.exports = [
  { id: 1, name: 'Олена Коваль', email: 'olena@example.com', city: 'Київ', role: 'Адміністратор', bio: 'Відповідає за налаштування системи та доступи.' },
  { id: 2, name: 'Андрій Шевченко', email: 'andrii@example.com', city: 'Львів', role: 'Розробник', bio: 'Пише серверну частину на Node.js.' },
  { id: 3, name: 'Марія Бойко', email: 'maria@example.com', city: 'Одеса', role: 'Дизайнер', bio: 'Розробляє інтерфейси та візуальний стиль.' },
  { id: 4, name: 'Іван Мельник', email: 'ivan@example.com', city: 'Харків', role: 'Тестувальник', bio: 'Перевіряє якість і стабільність сервісу.' }
];
