const express = require('express');
const articles = require('../data/articles');
const router = express.Router();

router.get('/', (req, res) => {
  res.render('ejs/articles.ejs', { title: 'Статті', articles });
});

router.get('/:articleId', (req, res) => {
  const article = articles.find((a) => a.id === Number(req.params.articleId));
  if (!article) {
    return res.status(404).render('404', { title: 'Не знайдено', message: 'Статтю не знайдено' });
  }
  res.render('ejs/article.ejs', { title: article.title, article });
});

module.exports = router;
