const express = require('express');
const users = require('../data/users');
const router = express.Router();

router.get('/', (req, res) => {
  res.render('users', { title: 'Користувачі', users });
});

router.get('/:userId', (req, res) => {
  const person = users.find((u) => u.id === Number(req.params.userId));
  if (!person) {
    return res.status(404).render('404', { title: 'Не знайдено', message: 'Користувача не знайдено' });
  }
  res.render('user', { title: person.name, person });
});

module.exports = router;
